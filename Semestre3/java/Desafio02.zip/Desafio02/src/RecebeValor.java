// Interface RecebeValor
public interface RecebeValor {
    void receber(double valor);
}