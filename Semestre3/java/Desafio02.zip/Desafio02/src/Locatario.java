// Classe Locatário
public class Locatario extends Pessoa {
    
    public Locatario(String nome, String cpf, String telefone, String email) {
        super(nome, cpf, telefone, email);
    }
}